import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import "./Dashboard.css"; // Seu arquivo CSS intacto pode ser importado aqui

// Importando nossos novos componentes
import Header from "./components/Header"; // Ajuste o caminho se necessário
import StatusCadastro from "./components/StatusCadastro";
import MeusPerfis from "./components/MeusPerfis";
import DadosCadastrais from "./components/DadosCadastrais";
import ModalLocador from "./components/modals/ModalLocador";
import ModalLocatario from "./components/modals/ModalLocatario";
import ModalEndereco from "./components/modals/ModalEndereco";

export default function Dashboard() {
    const { usuarioLogado, atualizarUsuario } = useAuth();
    const navigate = useNavigate();
    const [modalAberto, setModalAberto] = useState(null);

    const [perfilLocador, setPerfilLocador] = useState(null);
    const [perfilLocatario, setPerfilLocatario] = useState(null);

    // 'locador' quando a pessoa tentou anunciar sem ter perfil de locatário:
    // ela é levada ao cadastro de locatário e, ao concluir, segue para o de locador
    const [aposLocatario, setAposLocatario] = useState(null);

    // Consulta na API se o usuário já tem conta de Locador ou Locatário criada
    useEffect(() => {
        if (usuarioLogado?.id) {
            fetch(`http://localhost:8080/api/locadores/usuario/${usuarioLogado.id}`)
                .then(res => res.ok ? res.json() : null)
                .then(data => setPerfilLocador(data))
                .catch(() => setPerfilLocador(null));

            fetch(`http://localhost:8080/api/locatarios/usuario/${usuarioLogado.id}`)
                .then(res => res.ok ? res.json() : null)
                .then(data => setPerfilLocatario(data))
                .catch(() => setPerfilLocatario(null));
        }
    }, [usuarioLogado]);

    // Lógicas de checagem
    const temDocumento = Boolean(perfilLocador || perfilLocatario);
    const temTelefone = Boolean(usuarioLogado?.telefone && usuarioLogado.telefone.trim() !== "");
    const temEndereco = Boolean(usuarioLogado?.endereco && usuarioLogado.endereco.cep);
    const contaCompleta = temDocumento && temTelefone && temEndereco;

    // Ter perfil de locatário é pré-requisito para virar locador
    const ehLocatario = Boolean(usuarioLogado?.isLocatario || perfilLocatario);

    // Único ponto de abertura de modais dos perfis: bloqueia o de locador sem locatário
    const abrirModal = (qual) => {
        if (qual === "locador" && !ehLocatario) {
            setAposLocatario("locador");
            setModalAberto("locatario");
            return;
        }
        setAposLocatario(null);
        setModalAberto(qual);
    };

    const fecharModal = () => {
        setAposLocatario(null);
        setModalAberto(null);
    };

    // Função universal para fechar o modal e atualizar o Contexto de Auth
    const handleSucessoModal = async () => {
        const seguirParaLocador = modalAberto === "locatario" && aposLocatario === "locador";
        setAposLocatario(null);
        setModalAberto(seguirParaLocador ? "locador" : null);
        if (atualizarUsuario) await atualizarUsuario();
    };

    return (
        <div className="dashboard">

            <main className="main">
                <div className="main-header">
                    <div>
                        <h3>Painel do Cliente</h3>
                        <p>Seja bem-vindo ao seu painel de locações de espaços para eventos.</p>
                    </div>
                    <button onClick={() => navigate("/minhas-reservas")} className="btn btn-destaque">
                        📅 Minhas Reservas
                    </button>
                </div>

                <StatusCadastro 
                    contaCompleta={contaCompleta} 
                    temDocumento={temDocumento} 
                    temTelefone={temTelefone} 
                    temEndereco={temEndereco} 
                />

                <MeusPerfis 
                    usuarioLogado={usuarioLogado} 
                    ehLocatario={ehLocatario}
                    setModalAberto={abrirModal} 
                />

                <DadosCadastrais 
                    usuarioLogado={usuarioLogado} 
                    temEndereco={temEndereco} 
                    setModalAberto={setModalAberto} 
                />
            </main>

            {/* Modais */}
            {modalAberto === 'locador' && ehLocatario && (
                <ModalLocador 
                    usuarioLogado={usuarioLogado} 
                    onClose={fecharModal} 
                    onSuccess={handleSucessoModal} 
                />
            )}

            {modalAberto === 'endereco' && (
                <ModalEndereco 
                    usuarioLogado={usuarioLogado} 
                    onClose={() => setModalAberto(null)} 
                    onSuccess={handleSucessoModal} 
                />
            )}

            {modalAberto === 'locatario' && (
                <ModalLocatario 
                    usuarioLogado={usuarioLogado} 
                    onClose={fecharModal} 
                    onSuccess={handleSucessoModal} 
                    setPerfilLocatario={setPerfilLocatario}
                />
            )}
        </div>
    );
}